"""Rebuild workspace/extra_data/lending_club_36m_wide.csv from its two parts and check its SHA-256.

The file is 128 MB, above GitHub's upload limit, so the repository stores it in two parts
(loans issued 2007-2014 and loans issued 2015), each with the header row.
Run from the repository root after unzipping:  python code/join_data_parts.py
"""
import hashlib, json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
d = root / 'workspace' / 'extra_data'
p1, p2 = d / 'lending_club_36m_wide.part1_2007-2014.csv', d / 'lending_club_36m_wide.part2_2015.csv'
out = d / 'lending_club_36m_wide.csv'
for p in (p1, p2):
    if not p.exists():
        raise SystemExit(f'missing {p}: unzip data_lending_club_36m_part1.zip and data_lending_club_36m_part2.zip first')
a = p1.read_bytes()
b = p2.read_bytes()
b = b[b.index(b'\n') + 1:]          # drop the repeated header row
out.write_bytes(a + b)
h = hashlib.sha256(out.read_bytes()).hexdigest()
expected = next(o['sha256'] for o in json.loads((d / 'raw_manifest.json').read_text())['outputs']
                if o['file'] == 'lending_club_36m_wide.csv')
print('wrote', out, '| SHA-256 matches manifest:', h == expected)
if h != expected:
    raise SystemExit('checksum mismatch: re-download the two parts')
