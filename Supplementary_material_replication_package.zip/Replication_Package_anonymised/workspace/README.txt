This folder is the "Q2" working folder that the notebooks look for.  Point the notebooks at it with

    export Q2_DIR=/full/path/to/Replication_Package/workspace        (macOS / Linux)
    set Q2_DIR=C:\full\path\to\Replication_Package\workspace          (Windows)

before starting Jupyter, or copy this folder to your Desktop and rename it Q2.

Included (Lending Club extracts, see ../README.md for provenance):
  extra_data/lending_club_36m_wide.csv      resolved 36-month loans issued 2007-2015 (582,113 rows)
  extra_data/lending_club_60m_wide.csv      resolved 60-month loans issued 2010-2013 (53,506 rows)
  extra_data/raw_manifest.json              extraction manifest with SHA-256 of the raw file and of both extracts
  lending_club_real_36m.csv                 15-column version used by Conformal_Prediction_Credit_Risk_RUN.ipynb

NOT included (see ../README.md):
  archive/                                  put the Kaggle file accepted_2007_to_2018Q4 (.csv/.csv.gz/.zip) here
  extra_data/payments.csv, label_dates.csv  created from the raw file by Mega_Analysis / Final_Analysis on their first run
  extra_data/prosper/prosperLoanData.csv    see extra_data/prosper/README.txt
